﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicacionFestivos.Dominio.Entidades
{
    [Table ("Tipo")]
    public class Tipo
    {
        [Column ("Id")]
        public int Id { get; set; }

        [Column ("Tipo"), StringLength (100)]

        public string tipo { get; set;}
    }
}
