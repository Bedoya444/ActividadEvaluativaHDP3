﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AplicacionFestivos.Dominio.Entidades;

namespace AplicacionFestivos.Core.Interfaces.Servicios
{
    public interface IFestivosServicios
    {
        Task<IEnumerable<Festivo>> ObtenerTodo();

        Task<Festivo> Obtener(int id);

        Task<IEnumerable<Festivo>> Buscar(int indiceDato, string Dato);

        Task<Festivo> Agregar(Festivo festivo);

        Task<Festivo> Modificar(Festivo festivo);

        Task<bool> Eliminar(int id);

        Task<bool> EsFestivo(DateTime fecha);

        Task<bool> EsFechaValida(DateTime fecha);

        Task<bool> NoEsFestivo(DateTime fecha);
    }
}

